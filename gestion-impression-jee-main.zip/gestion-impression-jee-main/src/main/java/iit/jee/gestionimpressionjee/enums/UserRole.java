package iit.jee.gestionimpressionjee.enums;

public enum UserRole {
    ADMIN,
    ENSEIGNANT,
    AGENT,

}
